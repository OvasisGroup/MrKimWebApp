<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>



<section>
    categories
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asd/Desktop/desktop/prod/mrkim/resources/views/category.blade.php ENDPATH**/ ?>